package eu.kanade.tachiyomi.extension.pt.jondomingues

import eu.kanade.tachiyomi.network.GET
import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.online.ParsedHttpSource
import eu.kanade.tachiyomi.util.asJsoup
import okhttp3.Headers
import okhttp3.Request
import okhttp3.Response
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class JonDomingues : ParsedHttpSource() {

    override val name = "Jon Domingues"
    override val baseUrl = "https://jondomingues.com"
    override val lang = "pt-BR"
    override val supportsLatest = true

    override val headers: Headers = super.headersBuilder()
        .add("Referer", "$baseUrl/")
        .add("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130.0 Mobile Safari/537.36")
        .add("Accept-Language", "pt-BR,pt;q=0.9,en;q=0.7")
        .build()

    override fun popularMangaRequest(page: Int): Request =
        GET(if (page == 1) baseUrl else "$baseUrl/page/$page/", headers)

    override fun latestUpdatesRequest(page: Int): Request =
        GET(if (page == 1) baseUrl else "$baseUrl/page/$page/", headers)

    override fun searchMangaRequest(page: Int, query: String, filters: FilterList): Request {
        val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.name())
        val url = "$baseUrl/?s=$encoded" + if (page > 1) "&paged=$page" else ""
        return GET(url, headers)
    }

    override fun popularMangaSelector(): String = "article"
    override fun latestUpdatesSelector(): String = popularMangaSelector()
    override fun searchMangaSelector(): String = popularMangaSelector()

    override fun popularMangaFromElement(element: Element): SManga = mangaFromElement(element)
    override fun latestUpdatesFromElement(element: Element): SManga = mangaFromElement(element)
    override fun searchMangaFromElement(element: Element): SManga = mangaFromElement(element)

    private fun mangaFromElement(element: Element): SManga {
        val link = element.selectFirst("h1 a[href], h2 a[href], h3 a[href], a[href]")
        val image = element.selectFirst("img")
        val title = link?.text()?.trim().orEmpty()
            .ifBlank { image?.attr("alt")?.trim().orEmpty() }

        return SManga.create().apply {
            this.title = title
            url = link?.attr("href")?.let { normalizeUrl(it) } ?: ""
            thumbnail_url = image?.let { extractImageUrl(it) }
        }
    }

    private fun normalizeUrl(value: String): String {
        if (value.startsWith(baseUrl)) return value.removePrefix(baseUrl)
        if (value.startsWith("http")) return value
        return if (value.startsWith("/")) value else "/$value"
    }

    private fun absoluteUrl(value: String): String = when {
        value.startsWith("http://") || value.startsWith("https://") -> value
        value.startsWith("//") -> "https:$value"
        value.startsWith("/") -> baseUrl + value
        else -> "$baseUrl/$value"
    }

    private fun extractImageUrl(image: Element): String {
        val value = sequenceOf("data-src", "data-lazy-src", "data-original", "src")
            .map { image.attr(it) }
            .firstOrNull { it.isNotBlank() }
            .orEmpty()
        return if (value.isBlank()) "" else absoluteUrl(value)
    }

    override fun popularMangaNextPageSelector(): String =
        "a.next, a.next.page-numbers, a[rel=next]"

    override fun latestUpdatesNextPageSelector(): String = popularMangaNextPageSelector()
    override fun searchMangaNextPageSelector(): String = popularMangaNextPageSelector()

    override fun mangaDetailsParse(document: Document): SManga {
        val title = document.selectFirst("h1.entry-title, h1")?.text()?.trim().orEmpty()
        val description = document.select(
            ".entry-content p, .post-content p, .wp-block-post-content p"
        ).joinToString("\n\n") { it.text().trim() }.trim()

        val cover = document.selectFirst("meta[property=og:image]")?.attr("content")
            ?.takeIf { it.isNotBlank() }
            ?: document.selectFirst(".entry-content img, article img")?.let { extractImageUrl(it) }

        return SManga.create().apply {
            this.title = title
            this.description = description
            thumbnail_url = cover
            initialized = true
        }
    }

    override fun chapterListSelector(): String =
        "a[href*='ler-online'], a[href*='ler-absolute']"

    override fun chapterFromElement(element: Element): SChapter =
        SChapter.create().apply {
            name = element.text().trim().ifBlank { "Ler online" }
            url = normalizeUrl(element.attr("href"))
        }

    override fun chapterListParse(response: Response): List<SChapter> {
        val document = response.asJsoup()
        val readerLink = document.select("a[href]").firstOrNull {
            it.attr("href").contains("ler-", ignoreCase = true) ||
                it.text().contains("ler online", ignoreCase = true)
        } ?: return emptyList()

        return listOf(
            SChapter.create().apply {
                name = "Ler online"
                url = normalizeUrl(readerLink.attr("href"))
            }
        )
    }

    override fun pageListParse(document: Document): List<Page> {
        val pageImages = document.select("img").mapNotNull { image ->
            if (!image.attr("alt").contains("página", ignoreCase = true)) {
                return@mapNotNull null
            }

            val source = sequenceOf("data-src", "data-lazy-src", "data-original", "src")
                .map { image.attr(it) }
                .firstOrNull { it.isNotBlank() }
                ?: image.attr("srcset").split(",").lastOrNull()
                    ?.trim()?.substringBefore(" ")
                ?: return@mapNotNull null

            absoluteUrl(source).takeIf { it.startsWith("http") }
        }.distinct()

        return pageImages.mapIndexed { index, imageUrl ->
            Page(index, "", imageUrl)
        }
    }

    override fun imageUrlParse(document: Document): String =
        document.selectFirst("img")?.let { extractImageUrl(it) }
            ?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("Imagem não encontrada na resposta.")

    override fun imageRequest(page: Page): Request =
        GET(page.imageUrl ?: throw IllegalStateException("Página sem URL de imagem."), headers)

    override fun getMangaUrl(manga: SManga): String = baseUrl + manga.url
    override fun getChapterUrl(chapter: SChapter): String = baseUrl + chapter.url
}
