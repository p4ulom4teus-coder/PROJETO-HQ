# Módulo Jon Domingues

Fonte HTML para o Mihon (API legada 1.4). O catálogo é extraído de páginas WordPress e a leitura usa os `img[alt]` que identificam páginas no leitor do site.

A extensão não inclui nem redistribui imagens. Ela solicita os endereços diretamente ao domínio do site.
