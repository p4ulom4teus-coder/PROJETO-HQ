# Jon Domingues — extensão para Mihon

Extensão experimental em português (pt-BR) para o site https://jondomingues.com/.

## O que ela faz
- Lista quadrinhos a partir da página inicial do site.
- Pesquisa pelo mecanismo WordPress (`/?s=...`).
- Abre a página de detalhes da HQ.
- Detecta o link **Ler online** e cria um capítulo para o leitor nativo do Mihon.
- Extrai as imagens da página de leitura diretamente do HTML, sem presumir nomes ou sequência de arquivos.

O primeiro caso de teste é **Invencível #9 (2003)**:
- Detalhes: https://jondomingues.com/invencivel-9/
- Leitor: https://jondomingues.com/ler-online-invencivel-9/
- O site informa 28 páginas. A extensão extrai os endereços reais das imagens na página do leitor.

## Compatibilidade
O projeto foi estruturado como extensão Tachiyomi 1.4 (`extensions-lib`), compatível com Mihon 0.21.3. O changelog do Mihon informa que 0.21.3 é a última versão principal compatível com extensões Tachiyomi 1.4. Não atualize o Mihon para uma versão principal posterior sem antes verificar a compatibilidade desta extensão.

## Como gerar o APK (sem Android Studio)
1. Crie um repositório **público** no GitHub.
2. Envie o conteúdo deste ZIP para a raiz do repositório (não envie a pasta externa `jon-domingues-mihon`; envie os arquivos que estão dentro dela).
3. Abra a aba **Actions** do seu repositório e permita a execução de workflows, se o GitHub pedir.
4. Abra **Build Jon Domingues extension** e toque em **Run workflow**.
5. Quando terminar, abra a execução concluída e baixe o arquivo em **Artifacts** (`jon-domingues-debug-apk`).
6. No Android, abra o APK baixado e instale. Se o Android pedir, autorize a instalação desta origem.
7. No Mihon, use **Navegar → Extensões → menu/Importar APK local** (o nome pode variar) e selecione o APK, caso ele não apareça automaticamente.

O workflow compila a extensão usando o projeto-base arquivado do Tachiyomi, que contém o sistema de build antigo esperado por Mihon 0.21.3.

## Limitações desta primeira versão
- O catálogo depende da estrutura HTML atual do site. Se o site alterar o tema, os seletores podem precisar de ajuste.
- A extensão não hospeda nem armazena quadrinhos; ela apenas lê os metadados e as imagens servidas pelo site.
- A compilação em GitHub Actions ainda precisa ser executada para confirmar o APK no ambiente real. Este ZIP contém o projeto e o workflow; não é um APK já compilado.

## Arquivos
- `src/pt/jondomingues/`: módulo da extensão.
- `.github/workflows/build.yml`: compilação automática.
